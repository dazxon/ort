package ejercicio03;

/*
Reutilizando las clases del ejercicio anterior, agregar la clase Hito (con fecha, descripción,
personas involucradas) para poder agregar momentos importantes en la vida de la persona
(puede tener 0 a N). Un mismo hito puede ser utilizado para más de una persona.


la verdad que no lo entendi para nada, no se si soy yo o el ejercicio carece de explicacion, no se si tengo que hacer
un arraylist de personas dentro de la clase hito, si a la clase persona debo agregarle el atributo hito, medio flojeli
*/
package ejercicio03;

public class Hito {
	
	private String fecha;
	private String descripcion;
	
}

package ejercicio03;

public enum TipoDeLinea {
	
	CELULAR,FIJO,FAX;
	
}

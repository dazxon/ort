package ejercicio01;

public enum TipoDeLinea {
	
	CELULAR,FIJO,FAX;
	
}

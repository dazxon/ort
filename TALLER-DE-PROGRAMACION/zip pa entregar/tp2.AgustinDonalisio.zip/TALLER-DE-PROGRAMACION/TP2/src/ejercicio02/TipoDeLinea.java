package ejercicio02;

public enum TipoDeLinea {
	
	CELULAR,FIJO,FAX;
	
}

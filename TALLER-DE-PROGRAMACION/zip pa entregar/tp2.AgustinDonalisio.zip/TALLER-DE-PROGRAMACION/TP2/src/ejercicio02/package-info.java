package ejercicio02;

/*
Reutilizando las clases del ejercicio anterior, extender la clase Persona para que pueda tener
de 0 a N Mascotas (contiene el nombre y el tipo de animal, ambos String). Debe tener los
métodos necesarios para agregar nuevos datos o eliminar cada uno de los existentes (menos
los datos de la persona). Determinar si corresponde utilizar composición y agregación. Una
salida posible podría ser la siguiente:

Messi, Lionel
Telefonos: Celular:
549-114111-2222
Celular:
068-032444-5678 Fijo:
054-4411-5472 Emails:
lio@messi.com
liomessi_newells@hotmai
l.com Mascotas: Perro,
Pluto Gato, Felix
Conejo, Bugs


*/
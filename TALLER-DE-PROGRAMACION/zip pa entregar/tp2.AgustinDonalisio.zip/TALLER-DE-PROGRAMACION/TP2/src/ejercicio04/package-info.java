package ejercicio04;
/*
Crear la clase Vivienda que tendrá una Dirección (compuesta por: calle, altura, piso y
departamento) y que además pueda contener personas (nombre, apellido y edad) y muebles
(nombre, material y color). La salida deberá ser la siguiente:

Vivienda 1: Direccion: Montañeses
1234 4°”C” Personas: Nombre:
Arturo Roman, Edad: 53 Nombre:
Mónica Gaztambide, Edad: 35
Muebles: Mesa de Madera color
Marrón. Mesada de Mármol color
Rojo Perchero de Metal color
Negro Sillón de Cuero color Azul
*/